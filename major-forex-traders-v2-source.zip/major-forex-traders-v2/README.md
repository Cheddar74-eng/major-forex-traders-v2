# MAJOR FOREX TRADERS V2.0

Phone-managed Android starter project. GitHub Actions builds a debug APK automatically.

## Current build scope
- Offline technical scanner using user-entered closing prices (EMA 9/21 and RSI 14).
- 1% maximum risk cash calculator.
- No Deriv API connection, live market feed, or trade execution.
- Demo/manual review only. Signals are not financial advice.

## Build
Push this repository to GitHub. Open **Actions**, enable workflows if prompted, then run **Build Android APK**. Download `major-forex-traders-debug-apk` from the completed workflow run's Artifacts section. Install the APK on Android and allow installation from the browser/files app if Android asks.

## Project
Native Android WebView shell; local HTML/JavaScript interface. Android build runs on GitHub-hosted runners, not on the phone.
